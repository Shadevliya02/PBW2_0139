<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <x-layout>
        <a href="/">Landing Page</a>
        <a href="/admin">Admin</a>

        <h1>Ini Halaman Landing Page</h1>
    </x-layout>
</body>
</html>